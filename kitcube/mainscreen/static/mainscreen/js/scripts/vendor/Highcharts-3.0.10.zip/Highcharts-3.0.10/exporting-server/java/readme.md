#Steps to build the Highcharts Server application for Java#
See http://docs.highcharts.com/#export-server-setup